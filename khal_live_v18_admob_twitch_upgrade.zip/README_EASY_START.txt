KHAL LIVE v9 — QUICK START

1. Install Node.js LTS: https://nodejs.org/
2. Extract this ZIP into a normal folder.
3. Double-click START_KHAL_LIVE.bat.
4. Wait for npm install (first run only) and the server to start.
5. Open http://localhost:3000 in Chrome.

PHONE PREVIEW:
- Keep your phone and computer on the same Wi-Fi.
- On the computer, open Command Prompt and run: ipconfig
- Find the IPv4 Address (example 192.168.1.20).
- On your phone open http://192.168.1.20:3000 using your actual address.
- For mobile camera/microphone, a secure HTTPS address is required by most browsers.

Demo coin top-ups are not real money. This is a development preview, not a public production launch.
