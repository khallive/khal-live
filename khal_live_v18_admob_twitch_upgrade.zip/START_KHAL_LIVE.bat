@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Install Node.js LTS from https://nodejs.org/ then run this file again.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing Khal Live packages for the first run...
  call npm install
  if errorlevel 1 (
    echo npm install failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
)
start "Khal Live Server" /D "%~dp0" cmd /k npm start
timeout /t 3 /nobreak >nul
start "Khal Live" http://localhost:3000
