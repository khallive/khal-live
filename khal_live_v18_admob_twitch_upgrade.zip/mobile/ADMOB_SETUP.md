# Khal Live AdMob setup

Configured IDs:

- App ID: `ca-app-pub-9211419038317507~7775185215`
- Banner: `ca-app-pub-9211419038317507/7208209004`
- Rewarded: `ca-app-pub-9211419038317507/2816256594`
- App Open: `ca-app-pub-9211419038317507/4523858429`

The mobile package includes `@capacitor-community/admob` 8.2.x. After `npm install` and `npx cap sync`, add the App ID to AndroidManifest/strings as required by the plugin, then build the Android app.

The web UI does not request ads in a normal browser. On native builds, the banner is shown on discovery/home, the rewarded flow is user initiated, and the App Open ad is prepared/shown on app launch and eligible foreground resumes with a cooldown. Live video and active broadcasting are not interrupted.

## Testing

Use Google test ad units while developing. Do not repeatedly click production ads during testing; Google warns that live production ads should not be used for development. Replace test IDs with the supplied production IDs only when the app is ready for release.

## Reward security

The rewarded result is displayed to the user, but Khal Coins should not be granted from an unverified client result in production. Use AdMob server-side verification (SSV) and grant coins from the backend after verification.


## Android native App ID

After `npx cap add android`, add this inside `<application>` in `android/app/src/main/AndroidManifest.xml`:

```xml
<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="@string/admob_app_id" />
```

And add this to `android/app/src/main/res/values/strings.xml`:

```xml
<string name="admob_app_id">ca-app-pub-9211419038317507~7775185215</string>
```

The supplied IDs are production IDs. For development, switch the JS ad-unit IDs to Google's test units until the app is ready for release.
