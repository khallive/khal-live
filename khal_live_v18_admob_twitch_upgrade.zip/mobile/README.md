# Khal Live mobile wrapper

This is the native-app build foundation. It uses Capacitor so the same Khal Live web UI can be packaged for Android and iOS.

From this folder, after Node.js and the required native SDKs are installed:
- `npm install`
- `npx cap add android` then `npx cap sync` and `npx cap open android`
- `npx cap add ios` then `npx cap sync` and `npx cap open ios` (macOS/Xcode required)

For mobile digital coin purchases, implement the platform's approved in-app purchase system rather than putting a web card form inside the native app. Server-side receipt validation should credit coins.


## AdMob

See `ADMOB_SETUP.md`. The current AdMob App ID, Banner unit, and Rewarded unit are configured in `public/admob.js`.
