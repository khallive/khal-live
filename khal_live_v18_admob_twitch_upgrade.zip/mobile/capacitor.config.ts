import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.khalapp.khallivestreaming',
  appName: 'Khal Live',
  webDir: '../public',
  server: { androidScheme: 'https' }
};
export default config;
