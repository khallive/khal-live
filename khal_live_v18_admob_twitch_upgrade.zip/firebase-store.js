const fs = require('fs');
const path = require('path');

let firebaseApp = null;
let firestore = null;
let firebaseMode = 'local';
let syncTimer = null;
let syncRunning = false;

async function initFirebaseStore() {
  const enabled = String(process.env.FIREBASE_ENABLED || 'false').toLowerCase() === 'true';
  if (!enabled) return { enabled: false, mode: 'local' };

  try {
    const { initializeApp, applicationDefault, cert, getApps } = require('firebase-admin/app');
    const { getFirestore } = require('firebase-admin/firestore');

    if (getApps().length) firebaseApp = getApps()[0];
    else {
      const serviceJson = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
      if (serviceJson) {
        firebaseApp = initializeApp({ credential: cert(JSON.parse(serviceJson)), projectId: process.env.FIREBASE_PROJECT_ID || undefined });
      } else {
        firebaseApp = initializeApp({ credential: applicationDefault(), projectId: process.env.FIREBASE_PROJECT_ID || undefined });
      }
    }
    firestore = getFirestore(firebaseApp);
    firebaseMode = 'firestore';
    return { enabled: true, mode: firebaseMode, projectId: process.env.FIREBASE_PROJECT_ID || 'application-default' };
  } catch (error) {
    console.error('[Firebase] Disabled because initialization failed:', error.message);
    firebaseApp = null;
    firestore = null;
    firebaseMode = 'local';
    return { enabled: false, mode: 'local', error: error.message };
  }
}

async function hydrateDatabase(db, localFile) {
  if (!firestore) return { source: 'local' };
  const usersSnap = await firestore.collection('users').get();
  const sessionsSnap = await firestore.collection('sessions').get();

  if (usersSnap.empty && sessionsSnap.empty) {
    await syncDatabase(db);
    return { source: 'local-migrated-to-firebase', users: db.users.length };
  }

  db.users = usersSnap.docs.map(d => d.data());
  db.sessions = sessionsSnap.docs.map(d => d.data());
  fs.writeFileSync(localFile, JSON.stringify(db, null, 2));
  return { source: 'firebase', users: db.users.length };
}

async function syncDatabase(db) {
  if (!firestore || syncRunning) return;
  syncRunning = true;
  try {
    const writer = firestore.bulkWriter();
    writer.onWriteError(error => {
      if (error.failedAttempts < 3) return true;
      console.error('[Firebase] write failed:', error.message);
      return false;
    });
    const users = Array.isArray(db.users) ? db.users : [];
    const sessions = Array.isArray(db.sessions) ? db.sessions : [];
    for (const user of users) writer.set(firestore.collection('users').doc(String(user.id)), user);
    for (const session of sessions) writer.set(firestore.collection('sessions').doc(String(session.token)), session);
    await writer.close();
  } catch (error) {
    console.error('[Firebase] sync failed:', error.message);
  } finally {
    syncRunning = false;
  }
}

function scheduleSync(db) {
  if (!firestore) return;
  clearTimeout(syncTimer);
  syncTimer = setTimeout(() => syncDatabase(db), 300);
}

async function firebaseDiagnostic() {
  if (!firestore) {
    return {
      connected: false,
      mode: firebaseMode,
      reason: String(process.env.FIREBASE_ENABLED || 'false').toLowerCase() !== 'true'
        ? 'FIREBASE_ENABLED is not true.'
        : 'Firebase Admin did not initialize.'
    };
  }
  try {
    const ref = firestore.collection('_khal_live').doc('connection');
    await ref.set({ checkedAt: new Date().toISOString(), service: 'khal-live' }, { merge: true });
    const snap = await ref.get();
    return {
      connected: snap.exists,
      mode: firebaseMode,
      projectId: process.env.FIREBASE_PROJECT_ID || null,
      checkedAt: snap.exists ? snap.data().checkedAt : null
    };
  } catch (error) {
    return { connected: false, mode: firebaseMode, projectId: process.env.FIREBASE_PROJECT_ID || null, reason: error.message };
  }
}

function firebaseStatus() {
  return { enabled: !!firestore, mode: firebaseMode, projectId: process.env.FIREBASE_PROJECT_ID || null };
}

module.exports = { initFirebaseStore, hydrateDatabase, syncDatabase, scheduleSync, firebaseStatus, firebaseDiagnostic };
