# Khal Live — Firebase setup and verification

This build uses Firebase Cloud Firestore through the trusted Node.js Firebase Admin SDK. The Android Firebase file is included at `mobile/google-services.json`.

## Important package ID

The Capacitor Android package is now `com.khalapp.khallivestreaming`, matching the Firebase Android app registration supplied for this project.

## Server configuration

Copy `.env.example` to `.env` and set:

- `FIREBASE_ENABLED=true`
- `FIREBASE_PROJECT_ID=khal-live-streaming`
- `FIREBASE_SERVICE_ACCOUNT_JSON=<service-account-json-as-one-line-secret>` on a normal local/VPS server, OR use Google Application Default Credentials on Google-managed hosting.

Never commit the service-account secret or put it in browser code.

## Verify the connection

After `npm install`, run:

`npm run firebase:check`

A successful check writes and reads a small `_khal_live/connection` document in Firestore. The normal `/api/health` endpoint also reports `firebaseConnection.connected`.

## Firestore

Enable Cloud Firestore in the Firebase console before starting the server. The Node.js Admin SDK is used for trusted server operations; do not expose Admin credentials to users.

## Android

The supplied `google-services.json` is for the Android client. The app ID in `mobile/capacitor.config.ts` matches `com.khalapp.khallivestreaming`.

## Payments

Stripe remains separate and disabled until the payment/bank setup is ready.


## Khal Live v15 production checklist

1. Create/enable Firestore in the Firebase project `khal-live-streaming`.
2. Keep Firestore browser rules closed; the Khal Live server uses Firebase Admin.
3. Set `FIREBASE_ENABLED=true` and `FIREBASE_PROJECT_ID=khal-live-streaming`.
4. On local hosting, provide `FIREBASE_SERVICE_ACCOUNT_JSON` as a server secret; never commit it.
5. Set `ADMIN_USERNAMES` to your Khal owner username(s).
6. Run `npm run firebase:check`; then open `/api/health` and confirm `firebaseConnection.connected` is true.
7. The Android Firebase registration is `com.khalapp.khallivestreaming`; keep the Capacitor appId identical.

The v15 app includes owner moderation, reports, creator schedules, stream tags, followers-only chat, slow mode, clips metadata, search, notifications and creator dashboard APIs. Clips currently store clip metadata; production video clipping/recording requires persistent stream recording storage.
