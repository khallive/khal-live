# Khal Live feature audit — v18

This release adds the App Open AdMob unit, a persistent Settings centre, Stories, a Clips feed, and playback/notification/privacy preferences.

## Included in the current app
- Live discovery, categories, following, authenticated Go Live and watch rooms
- Live chat with reconnect/delivery handling, follower-only chat, slow mode, bans/reports/blocks
- Creator Studio, stream title/category/tags, schedules and creator analytics foundation
- Clips creation and a Clips feed
- Stories with 48-hour expiry and reactions (text-first foundation)
- Khal Coins, gifts, wallet and creator earnings/payout foundation
- Notifications foundation
- Account/profile, Privacy, Terms, Admin Studio
- Firebase/Firestore integration path with local fallback
- PWA + Capacitor mobile foundation
- AdMob Banner, Rewarded and App Open units
- Settings: appearance, notifications, autoplay/mute, PiP preference, chat preferences, personalized discovery, blocked-user access

## Twitch-like areas still requiring production implementation
These are intentionally not faked as complete features:
- Subscriptions and gifted subscriptions with real billing/entitlements
- VOD recording, replay processing, thumbnails and long-term storage
- Production media infrastructure: ingest, transcoding, adaptive bitrate, CDN, vertical/dual-format streaming and 1440p
- Raids, co-streaming/collaboration rooms and merged chats
- Polls, predictions, channel-points-style loyalty and Hype Train equivalent
- Direct messages/whispers and richer social graph
- Full emote/badge system and creator-managed channel cosmetics
- Extension/app ecosystem
- Full clip video generation/editing/export pipeline (the current clip endpoint stores metadata)
- Mature recommendation/search ranking and creator discovery
- Complete creator monetization, tax/KYC, refunds and payout operations
- Full moderation automation, audit logs and safety operations
- Push notifications and deep links through the native mobile apps

The architecture should add these incrementally rather than pretending a browser-to-browser WebRTC demo is a Twitch-scale streaming backend.
