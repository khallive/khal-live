const express=require("express");
const http=require("http");
const path=require("path");
const WebSocket=require("ws");
const fs=require("fs");
const crypto=require("crypto");
const Stripe=require("stripe");
const {initFirebaseStore,hydrateDatabase,syncDatabase,scheduleSync,firebaseStatus,firebaseDiagnostic}=require("./firebase-store");
const stripeSecret=process.env.STRIPE_SECRET_KEY||"";
const stripe=stripeSecret?new Stripe(stripeSecret):null;

const app=express();
const server=http.createServer(app);
const rateBuckets=new Map();
function rateLimit(limit,windowMs){return (req,res,next)=>{const key=(req.ip||req.socket.remoteAddress||"unknown")+":"+req.path;const now=Date.now();let b=rateBuckets.get(key);if(!b||now-b.start>windowMs)b={start:now,count:0};b.count++;rateBuckets.set(key,b);if(b.count>limit)return res.status(429).json({error:"Too many requests. Please wait a moment and try again."});next();};}
setInterval(()=>{const cutoff=Date.now()-15*60*1000;for(const [k,b] of rateBuckets)if(b.start<cutoff)rateBuckets.delete(k)},5*60*1000).unref();
const wss=new WebSocket.Server({server});
app.post("/api/payments/webhook",express.raw({type:"application/json"}),async(req,res)=>{
  if(!stripe)return res.status(503).send("Payments are not configured.");
  const signature=req.headers["stripe-signature"];
  let event;
  try{event=stripe.webhooks.constructEvent(req.body,signature,process.env.STRIPE_WEBHOOK_SECRET||"");}
  catch(err){return res.status(400).send("Invalid webhook signature.");}
  if(event.type==="checkout.session.completed"){
    const session=event.data.object;
    const user=db.users.find(u=>u.id===session.metadata?.userId);
    const coins=Math.max(0,Number(session.metadata?.coins)||0);
    const paymentId=String(session.payment_intent||session.id);
    if(user&&coins>0&&!((user.transactions||[]).some(t=>t.meta?.paymentId===paymentId))){
      user.coins=(user.coins||0)+coins;
      addTransaction(user,"coin_purchase",coins,{paymentId,packageId:session.metadata?.packageId,mode:"stripe"});
      saveDB();
    }
  }
  res.json({received:true});
});
app.use(express.json());
app.disable("x-powered-by");
app.use((req,res,next)=>{res.setHeader("X-Content-Type-Options","nosniff");res.setHeader("Referrer-Policy","strict-origin-when-cross-origin");res.setHeader("X-Frame-Options","SAMEORIGIN");next()});
app.use(express.static(path.join(__dirname,"public")));

const DB_FILE=path.join(__dirname,"data.json");
function loadDB(){
  try{return JSON.parse(fs.readFileSync(DB_FILE,"utf8"));}
  catch{return {users:[],sessions:[]};}
}
const db=loadDB();
if(!Array.isArray(db.users))db.users=[];
if(!Array.isArray(db.sessions))db.sessions=[];
if(!Array.isArray(db.schedules))db.schedules=[];
if(!Array.isArray(db.reports))db.reports=[];
if(!Array.isArray(db.clips))db.clips=[];
if(!Array.isArray(db.notifications))db.notifications=[];
if(!Array.isArray(db.blocks))db.blocks=[];
if(!Array.isArray(db.stories))db.stories=[];
const DEFAULT_PREFERENCES={darkMode:true,reduceMotion:false,liveNotifications:true,accountNotifications:true,storyNotifications:true,autoplay:false,muted:true,pip:true,chatVisible:true,chatSounds:false,personalized:true};
for(const u of db.users){u.preferences={...DEFAULT_PREFERENCES,...(u.preferences||{})}}
function adminUser(req){ const u=authUser(req); if(!u) return null; const admins=String(process.env.ADMIN_USERNAMES||"").split(",").map(x=>cleanUsername(x)).filter(Boolean); return admins.includes(u.username)?u:null; }
function requireAdmin(req,res,next){ const u=adminUser(req); if(!u)return res.status(403).json({error:"Admin access required."}); req.user=u; next(); }
function addNotification(userId,type,payload={}){ db.notifications.unshift({id:crypto.randomUUID(),userId,type,payload,read:false,createdAt:new Date().toISOString()}); db.notifications=db.notifications.slice(0,2000); }
function roomLiveInfo(){ return [...rooms.entries()].filter(([,r])=>r.live).map(([room,r])=>({room,title:r.title,category:r.category||"Just Chatting",tags:r.tags||[],viewers:[...r.peers].filter(x=>x._role==="viewer").length,creator:creatorInfo(r.broadcasterUserId)})); }

function saveDB(){fs.writeFileSync(DB_FILE,JSON.stringify(db,null,2));scheduleSync(db);}
function cleanUsername(v){return String(v||"").trim().toLowerCase().replace(/[^a-z0-9_]/g,"").slice(0,24)}
function publicUser(u){return {id:u.id,username:u.username,displayName:u.displayName,bio:u.bio||"",followers:u.followers||[],following:u.following||[],followersCount:(u.followers||[]).length,followingCount:(u.following||[]).length,coins:u.coins||0,creatorCoins:u.creatorCoins||0,earnings:u.earnings||0,createdAt:u.createdAt,avatar:u.avatar||"",role:u.role||"viewer",preferences:{...DEFAULT_PREFERENCES,...(u.preferences||{})}};}
function addTransaction(u,type,coins,meta={}){if(!Array.isArray(u.transactions))u.transactions=[];u.transactions.unshift({id:crypto.randomUUID(),type,coins,meta,createdAt:new Date().toISOString()});u.transactions=u.transactions.slice(0,100);}
function hashPassword(password,salt=crypto.randomBytes(16).toString("hex")){
  const hash=crypto.scryptSync(String(password),salt,64).toString("hex");
  return {salt,hash};
}
function findUser(name){const key=cleanUsername(name);return db.users.find(u=>u.username===key)}
function tokenFor(u){
  const token=crypto.randomBytes(32).toString("hex");
  db.sessions=db.sessions.filter(s=>s.expiresAt>Date.now());
  db.sessions.push({token,userId:u.id,expiresAt:Date.now()+1000*60*60*24*30});
  saveDB();return token;
}
function authUser(req){
  const header=String(req.headers.authorization||"");
  const token=header.startsWith("Bearer ")?header.slice(7):"";
  const session=db.sessions.find(s=>s.token===token && s.expiresAt>Date.now());
  return session?db.users.find(u=>u.id===session.userId):null;
}
function requireAuth(req,res,next){const u=authUser(req);if(!u)return res.status(401).json({error:"Please log in first."});req.user=u;next();}

app.post("/api/register",rateLimit(10,10*60*1000),(req,res)=>{
  const username=cleanUsername(req.body.username);
  const displayName=String(req.body.displayName||username).trim().slice(0,40);
  const password=String(req.body.password||"");
  if(username.length<3)return res.status(400).json({error:"Username must be at least 3 characters."});
  if(password.length<6)return res.status(400).json({error:"Password must be at least 6 characters."});
  if(findUser(username))return res.status(409).json({error:"That username is already taken."});
  const {salt,hash}=hashPassword(password);
  const user={id:crypto.randomUUID(),username,displayName,passwordHash:hash,passwordSalt:salt,bio:"",followers:[],following:[],coins:100,creatorCoins:0,earnings:0,transactions:[],preferences:{...DEFAULT_PREFERENCES},createdAt:new Date().toISOString()};
  db.users.push(user);saveDB();
  res.json({token:tokenFor(user),user:publicUser(user)});
});

app.post("/api/login",rateLimit(20,10*60*1000),(req,res)=>{
  const username=cleanUsername(req.body.username),password=String(req.body.password||"");
  const user=findUser(username);
  if(!user)return res.status(401).json({error:"Invalid username or password."});
  const {hash}=hashPassword(password,user.passwordSalt);
  if(!crypto.timingSafeEqual(Buffer.from(hash,"hex"),Buffer.from(user.passwordHash,"hex")))return res.status(401).json({error:"Invalid username or password."});
  res.json({token:tokenFor(user),user:publicUser(user)});
});

app.post("/api/logout",requireAuth,(req,res)=>{const header=String(req.headers.authorization||"");const token=header.slice(7);db.sessions=db.sessions.filter(s=>s.token!==token);saveDB();res.json({ok:true});});
app.get("/api/me",requireAuth,(req,res)=>res.json({user:publicUser(req.user)}));
app.get("/api/profile/:username",(req,res)=>{const user=findUser(req.params.username);if(!user)return res.status(404).json({error:"User not found."});res.json({user:publicUser(user)});});
app.get("/api/settings",requireAuth,(req,res)=>res.json({user:publicUser(req.user),preferences:{...DEFAULT_PREFERENCES,...(req.user.preferences||{})}}));
app.patch("/api/settings",requireAuth,(req,res)=>{const next={...DEFAULT_PREFERENCES,...(req.user.preferences||{})};for(const k of Object.keys(DEFAULT_PREFERENCES))if(typeof req.body[k]==="boolean")next[k]=req.body[k];req.user.preferences=next;saveDB();res.json({ok:true,preferences:next});});
app.get("/api/blocks",requireAuth,(req,res)=>res.json({blocks:db.blocks.filter(x=>x.ownerId===req.user.id)}));
app.get("/api/stories",(req,res)=>{const now=Date.now();db.stories=db.stories.filter(x=>new Date(x.expiresAt).getTime()>now);const username=cleanUsername(req.query.username||"");res.json({stories:db.stories.filter(x=>!username||x.username===username).slice(-100).reverse()});});
app.post("/api/stories",requireAuth,rateLimit(10,60*60*1000),(req,res)=>{const text=String(req.body.text||"").trim().slice(0,280);if(!text)return res.status(400).json({error:"Write something for your story."});const story={id:crypto.randomUUID(),userId:req.user.id,username:req.user.username,displayName:req.user.displayName,text,createdAt:new Date().toISOString(),expiresAt:new Date(Date.now()+48*60*60*1000).toISOString(),reactions:0};db.stories.push(story);db.stories=db.stories.slice(-2000);saveDB();res.json({story});});
app.post("/api/stories/:id/react",requireAuth,(req,res)=>{const story=db.stories.find(x=>x.id===req.params.id);if(!story)return res.status(404).json({error:"Story not found."});story.reactions=(story.reactions||0)+1;saveDB();res.json({ok:true,reactions:story.reactions});});

app.patch("/api/profile",requireAuth,(req,res)=>{const displayName=String(req.body.displayName??req.user.displayName).trim().slice(0,40);const bio=String(req.body.bio??req.user.bio).trim().slice(0,240);if(!displayName)return res.status(400).json({error:"Display name cannot be empty."});req.user.displayName=displayName;req.user.bio=bio;saveDB();res.json({user:publicUser(req.user)});});
app.get("/api/search",(req,res)=>{ const q=String(req.query.q||"").trim().toLowerCase().slice(0,80); const live=roomLiveInfo().filter(r=>!q||`${r.title} ${r.category} ${(r.tags||[]).join(" ")} ${r.creator?.username||""}`.toLowerCase().includes(q)); const creators=db.users.filter(u=>!q||`${u.username} ${u.displayName} ${u.bio||""}`.toLowerCase().includes(q)).slice(0,30).map(publicUser); res.json({rooms:live,creators}); });
app.get("/api/schedules",(req,res)=>{const username=cleanUsername(req.query.username||"");res.json({schedules:db.schedules.filter(x=>!username||x.username===username).filter(x=>new Date(x.startAt).getTime()>Date.now()-86400000).sort((a,b)=>new Date(a.startAt)-new Date(b.startAt)).slice(0,100)});});
app.post("/api/schedules",requireAuth,(req,res)=>{const startAt=new Date(req.body.startAt||"");if(!Number.isFinite(startAt.getTime())||startAt.getTime()<Date.now()-60000)return res.status(400).json({error:"Choose a future date and time."});const item={id:crypto.randomUUID(),username:req.user.username,title:String(req.body.title||"Khal Live Stream").trim().slice(0,120),category:String(req.body.category||"Just Chatting").slice(0,40),startAt:startAt.toISOString(),createdAt:new Date().toISOString()};db.schedules.push(item);saveDB();res.json({schedule:item});});
app.delete("/api/schedules/:id",requireAuth,(req,res)=>{const before=db.schedules.length;db.schedules=db.schedules.filter(x=>!(x.id===req.params.id&&x.username===req.user.username));saveDB();res.json({ok:db.schedules.length<before});});
app.get("/api/notifications",requireAuth,(req,res)=>{res.json({notifications:db.notifications.filter(x=>x.userId===req.user.id).slice(0,50)});});
app.post("/api/notifications/read",requireAuth,(req,res)=>{db.notifications.filter(x=>x.userId===req.user.id).forEach(x=>x.read=true);saveDB();res.json({ok:true});});
app.post("/api/clips",rateLimit(10,10*60*1000),requireAuth,(req,res)=>{const room=String(req.body.room||"").slice(0,50);const live=roomLiveInfo().find(x=>x.room===room);if(!live)return res.status(404).json({error:"That stream is no longer live."});const clip={id:crypto.randomUUID(),room,title:String(req.body.title||live.title||"Khal Live clip").slice(0,120),creator:live.creator,createdBy:req.user.username,createdAt:new Date().toISOString(),startOffset:Math.max(0,Number(req.body.startOffset)||0),duration:15};db.clips.push(clip);db.clips=db.clips.slice(-1000);saveDB();res.json({clip});});
app.get("/api/clips",(req,res)=>{const room=String(req.query.room||"");res.json({clips:db.clips.filter(x=>!room||x.room===room).slice(-50).reverse()});});
app.post("/api/report",rateLimit(10,10*60*1000),requireAuth,(req,res)=>{const reason=String(req.body.reason||"").trim().slice(0,120);if(!reason)return res.status(400).json({error:"Please choose a report reason."});const report={id:crypto.randomUUID(),reporter:req.user.username,room:String(req.body.room||"").slice(0,50),target:String(req.body.target||"").slice(0,50),reason,details:String(req.body.details||"").slice(0,500),status:"open",createdAt:new Date().toISOString()};db.reports.push(report);saveDB();res.json({ok:true,reportId:report.id});});
app.post("/api/block",requireAuth,(req,res)=>{const username=cleanUsername(req.body.username);if(!username||username===req.user.username)return res.status(400).json({error:"Invalid account."});const key=`${req.user.id}:${username}`;const exists=db.blocks.some(x=>x.key===key);if(exists)db.blocks=db.blocks.filter(x=>x.key!==key);else db.blocks.push({key,ownerId:req.user.id,username,createdAt:new Date().toISOString()});saveDB();res.json({blocked:!exists});});
app.get("/api/creator/dashboard",requireAuth,(req,res)=>{const gifts=(req.user.transactions||[]).filter(t=>t.type==="gift_received");const sent=(req.user.transactions||[]).filter(t=>t.type==="gift_sent");const live=roomLiveInfo().find(r=>r.creator?.id===req.user.id);res.json({followers:(req.user.followers||[]).length,following:(req.user.following||[]).length,creatorCoins:req.user.creatorCoins||0,earnings:req.user.earnings||0,giftsReceived:gifts.reduce((n,x)=>n+Math.max(0,x.coins||0),0),giftsSent:sent.reduce((n,x)=>n+Math.max(0,-x.coins||0),0),isLive:!!live,live,transactions:(req.user.transactions||[]).slice(0,20),schedules:db.schedules.filter(x=>x.username===req.user.username)});});
app.get("/api/admin/stats",requireAdmin,(req,res)=>{const live=roomLiveInfo();res.json({users:db.users.length,liveRooms:live.length,viewers:live.reduce((n,r)=>n+r.viewers,0),reportsOpen:db.reports.filter(x=>x.status==="open").length,totalCoins:db.users.reduce((n,u)=>n+(u.coins||0),0),creatorCoins:db.users.reduce((n,u)=>n+(u.creatorCoins||0),0),revenueCoins:db.users.reduce((n,u)=>n+(u.earnings||0),0),firebase:firebaseStatus()});});
app.get("/api/admin/reports",requireAdmin,(req,res)=>res.json({reports:db.reports.slice(-200).reverse()}));
app.patch("/api/admin/reports/:id",requireAdmin,(req,res)=>{const r=db.reports.find(x=>x.id===req.params.id);if(!r)return res.status(404).json({error:"Report not found."});r.status=["open","reviewing","resolved","dismissed"].includes(req.body.status)?req.body.status:r.status;saveDB();res.json({report:r});});
app.get("/api/wallet",requireAuth,(req,res)=>res.json({coins:req.user.coins||0,creatorCoins:req.user.creatorCoins||0,earnings:req.user.earnings||0,transactions:req.user.transactions||[]}));
const COIN_PACKAGES=[
  {id:"starter",coins:100,amountZar:10,label:"100 Coins"},
  {id:"basic",coins:550,amountZar:50,label:"550 Coins"},
  {id:"popular",coins:1200,amountZar:100,label:"1,200 Coins"},
  {id:"premium",coins:6500,amountZar:500,label:"6,500 Coins"}
];
app.get("/api/payments/config",(req,res)=>res.json({enabled:!!stripe,currency:"ZAR",packages:COIN_PACKAGES}));
app.post("/api/payments/create-checkout",rateLimit(10,10*60*1000),requireAuth,async(req,res)=>{
  if(!stripe)return res.status(503).json({error:"Real payments are not configured yet. Add STRIPE_SECRET_KEY and STRIPE_WEBHOOK_SECRET on the server first."});
  const pack=COIN_PACKAGES.find(x=>x.id===String(req.body.packageId));
  if(!pack)return res.status(400).json({error:"Coin package not found."});
  const base=String(process.env.PUBLIC_BASE_URL||"").replace(/\/$/,"");
  if(!base)return res.status(503).json({error:"PUBLIC_BASE_URL is not configured on the server."});
  try{
    const session=await stripe.checkout.sessions.create({
      mode:"payment",
      line_items:[{price_data:{currency:"zar",product_data:{name:`Khal Live — ${pack.label}`},unit_amount:pack.amountZar*100},quantity:1}],
      success_url:base+"/#wallet?payment=success",
      cancel_url:base+"/#wallet?payment=cancelled",
      client_reference_id:req.user.id,
      metadata:{userId:req.user.id,packageId:pack.id,coins:String(pack.coins)}
    });
    res.json({url:session.url});
  }catch(err){res.status(500).json({error:"Could not create payment session."});}
});

app.post("/api/wallet/demo-topup",requireAuth,(req,res)=>{
  const coins=Math.max(1,Math.min(100000,Number(req.body.coins)||0));
  req.user.coins=(req.user.coins||0)+coins;
  addTransaction(req.user,"demo_topup",coins,{mode:"demo"});
  saveDB();
  res.json({coins:req.user.coins,notice:"Demo coins added. No real payment was taken."});
});

const GIFTS={rose:{name:"Rose",emoji:"🌹",coins:10},heart:{name:"Heart",emoji:"❤️",coins:50},crown:{name:"Crown",emoji:"👑",coins:500},diamond:{name:"Diamond",emoji:"💎",coins:1000}};
app.get("/api/gifts",(req,res)=>res.json({gifts:GIFTS}));
app.get("/api/rooms",(req,res)=>{
  const live=[];
  for(const [id,room] of rooms.entries()){
    if(!room.live) continue;
    const creator=room.broadcasterUserId?db.users.find(u=>u.id===room.broadcasterUserId):null;
    live.push({room:id,title:room.title||"Khal Live Stream",category:room.category||"Just Chatting",tags:room.tags||[],slowMode:room.slowMode||0,followersOnly:!!room.followersOnly,creator:creator?{id:creator.id,username:creator.username,displayName:creator.displayName}:null,viewers:[...room.peers].filter(x=>x._role==="viewer").length});
  }
  res.json({rooms:live});
});

app.post("/api/gifts/send",rateLimit(30,60*1000),requireAuth,(req,res)=>{
  const gift=GIFTS[String(req.body.gift||"")];
  const roomId=String(req.body.room||"main").slice(0,50);
  if(!gift)return res.status(400).json({error:"Gift not found."});
  if((req.user.coins||0)<gift.coins)return res.status(400).json({error:"Not enough coins. Add demo coins or connect a real payment provider."});
  const room=rooms.get(roomId);
  const creatorId=room&&room.broadcasterUserId;
  const creator=creatorId?db.users.find(u=>u.id===creatorId):null;
  if(!creator)return res.status(400).json({error:"No authenticated creator is live in this room."});
  if(creator.id===req.user.id)return res.status(400).json({error:"You cannot send a gift to yourself."});
  req.user.coins-=gift.coins;
  creator.creatorCoins=(creator.creatorCoins||0)+gift.coins;
  creator.earnings=(creator.earnings||0)+gift.coins;
  addTransaction(req.user,"gift_sent",-gift.coins,{gift:gift.name,room:roomId,creator:creator.username});
  addTransaction(creator,"gift_received",gift.coins,{gift:gift.name,room:roomId,from:req.user.username});
  saveDB();
  for(const peer of room.peers)send(peer,{type:"gift",gift:{...gift,from:req.user.displayName||req.user.username}});
  res.json({ok:true,coins:req.user.coins,gift});
});

const payoutsEnabled=String(process.env.PAYOUTS_ENABLED||"false").toLowerCase()==="true";
app.post("/api/payout-request",rateLimit(5,60*60*1000),requireAuth,(req,res)=>{
  if(!payoutsEnabled)return res.status(503).json({error:"Creator payouts are not connected yet. Your creator coins remain in your account until payouts are enabled."});
  const coins=req.user.creatorCoins||0;
  if(coins<1000)return res.status(400).json({error:"You need at least 1,000 creator coins before requesting a payout."});
  req.user.creatorCoins=0;
  addTransaction(req.user,"payout_requested",-coins,{status:"pending"});
  saveDB();
  res.json({ok:true,message:"Payout request recorded as pending. Connect a real payout provider before production."});
});

app.post("/api/follow",requireAuth,(req,res)=>{
  const target=findUser(req.body.username);
  if(!target)return res.status(404).json({error:"User not found."});
  if(target.id===req.user.id)return res.status(400).json({error:"You cannot follow yourself."});
  const following=req.user.following.includes(target.id);
  if(following){req.user.following=req.user.following.filter(id=>id!==target.id);target.followers=target.followers.filter(id=>id!==req.user.id)}
  else{req.user.following.push(target.id);target.followers.push(req.user.id)}
  saveDB();res.json({following:!following,user:publicUser(target),me:publicUser(req.user)});
});

const rooms=new Map();
function creatorInfo(id){const u=id?db.users.find(x=>x.id===id):null;return u?{id:u.id,username:u.username,displayName:u.displayName}:null;}
function roomSnapshot(roomId){
  const room=rooms.get(roomId); if(!room) return null;
  return {room:roomId,title:room.title||"Khal Live Stream",viewers:[...room.peers].filter(x=>x._role==="viewer").length};
}
wss.on("connection",ws=>{
  let roomId=null,role=null,user=null,clientId=crypto.randomUUID();
  ws._clientId=clientId;
  ws.on("message",raw=>{
    let msg;try{msg=JSON.parse(raw)}catch{return}
    if(msg.type==="join"){
      roomId=String(msg.room||"main").slice(0,50); role=msg.role==="broadcaster"?"broadcaster":"viewer";
      if(msg.token){const session=db.sessions.find(s=>s.token===String(msg.token)&&s.expiresAt>Date.now());user=session?db.users.find(u=>u.id===session.userId):null;}
      if(role==="broadcaster"&&!user){send(ws,{type:"error",error:"You must be logged in to go live."});ws.close();return;}
      if(!rooms.has(roomId))rooms.set(roomId,{peers:new Set(),broadcaster:null,broadcasterUserId:null,title:"Khal Live Stream",live:false,category:"Just Chatting",tags:[],slowMode:0,followersOnly:false,banned:new Set(),timeouts:new Map()});
      const room=rooms.get(roomId);
      if(role==="broadcaster"&&room.broadcaster&&room.broadcaster.readyState===WebSocket.OPEN){send(ws,{type:"error",error:"This live room is already in use. Choose another room name."});ws.close();return;}
      room.peers.add(ws); ws._role=role; ws._userId=user&&user.id;
      if(role==="broadcaster"){
        room.broadcaster=ws; room.broadcasterUserId=user.id; room.title=String(msg.title||"Khal Live Stream").trim().slice(0,120)||"Khal Live Stream"; room.category=String(msg.category||"Just Chatting").slice(0,40)||"Just Chatting"; room.tags=Array.isArray(msg.tags)?msg.tags.map(x=>String(x).trim().slice(0,24)).filter(Boolean).slice(0,5):[]; room.slowMode=Math.max(0,Math.min(120,Number(msg.slowMode)||0)); room.followersOnly=!!msg.followersOnly; room.live=true;
      }
      send(ws,{type:"joined",role,room:roomId,clientId,title:room.title,category:room.category||"Just Chatting",creator:user?{id:user.id,username:user.username,displayName:user.displayName}:null});
      if(role==="viewer" && room.broadcaster){send(ws,{type:"broadcaster-present",broadcasterId:room.broadcaster._clientId,title:room.title,category:room.category||"Just Chatting",creator:creatorInfo(room.broadcasterUserId)});send(room.broadcaster,{type:"viewer-joined",viewerId:clientId});}
      if(role==="broadcaster")for(const peer of room.peers)if(peer!==ws&&peer._role==="viewer")send(peer,{type:"broadcaster-present",broadcasterId:clientId,title:room.title,category:room.category||"Just Chatting",creator:creatorInfo(room.broadcasterUserId)});
      return;
    }
    if(!roomId)return; const room=rooms.get(roomId); if(!room)return;
    if(msg.type==="chat"){
      const safe=String(msg.text||"").trim().slice(0,300); if(!safe)return;
      const uid=user?.id||clientId; if(room.banned?.has(uid))return send(ws,{type:"chat-error",error:"You are banned from this chat."});
      const until=room.timeouts?.get(uid)||0; if(until>Date.now())return send(ws,{type:"chat-error",error:`You are timed out for ${Math.ceil((until-Date.now())/1000)}s.`});
      if(room.followersOnly){
        if(!user)return send(ws,{type:"chat-error",error:"Followers-only chat is enabled. Log in and follow the creator to chat."});
        const creator=db.users.find(u=>u.id===room.broadcasterUserId);
        if(!creator || !(creator.followers||[]).includes(user.id))return send(ws,{type:"chat-error",error:"Followers-only chat is enabled. Follow the creator to chat."});
      }
      if(room.slowMode){const now=Date.now(); if(ws._lastChat&&now-ws._lastChat<room.slowMode*1000)return send(ws,{type:"chat-error",error:`Slow mode: wait ${room.slowMode}s.`}); ws._lastChat=now;}
      const name=user?(user.displayName||user.username):String(msg.name||"Viewer").slice(0,30);
      const payload={type:"chat",name,text:safe,userId:user?.id||null,clientMessageId:String(msg.clientMessageId||"")};
      for(const peer of room.peers)send(peer,payload);
      send(ws,{type:"chat-sent",clientMessageId:String(msg.clientMessageId||"")});
      return;
    }
    if(msg.type==="moderate"&&role==="broadcaster"&&user?.id===room.broadcasterUserId){const target=[...room.peers].find(p=>p._clientId===msg.target);if(!target)return;const tid=target._userId||target._clientId;const action=String(msg.action||"");if(action==="ban"){room.banned.add(tid);send(target,{type:"chat-error",error:"You were banned from this chat."});target.close();}else if(action==="timeout"){const sec=Math.max(5,Math.min(3600,Number(msg.seconds)||60));room.timeouts.set(tid,Date.now()+sec*1000);send(target,{type:"chat-error",error:`You were timed out for ${sec}s.`});}return;}
    if(msg.type==="offer" && role==="broadcaster"){
      const target=[...room.peers].find(p=>p._clientId===msg.to && p._role==="viewer"); if(target)send(target,{type:"offer",data:msg.data,from:clientId,title:room.title}); return;
    }
    if(msg.type==="answer" && role==="viewer"){
      if(room.broadcaster)send(room.broadcaster,{type:"answer",data:msg.data,from:clientId}); return;
    }
    if(msg.type==="ice"){
      const target=msg.to==="broadcaster"?room.broadcaster:[...room.peers].find(p=>p._clientId===msg.to);
      if(target)send(target,{type:"ice",data:msg.data,from:clientId}); return;
    }
  });
  ws.on("close",()=>{
    if(!roomId||!rooms.has(roomId))return; const room=rooms.get(roomId); room.peers.delete(ws);
    if(role==="viewer" && room.broadcaster)send(room.broadcaster,{type:"viewer-left",viewerId:clientId});
    if(role==="broadcaster" && room.broadcaster===ws){
      room.live=false; room.broadcaster=null; room.broadcasterUserId=null;
      for(const peer of room.peers)send(peer,{type:"broadcaster-left"});
    }
    if(room.peers.size===0)rooms.delete(roomId);
  });
});
app.get("/api/health",async(req,res)=>res.json({ok:true,service:"khal-live",paymentsConfigured:!!stripe,rooms:rooms.size,firebase:firebaseStatus(),firebaseConnection:await firebaseDiagnostic(),users:db.users.length,reportsOpen:db.reports.filter(x=>x.status==="open").length}));
app.use((err,req,res,next)=>{console.error(err);if(res.headersSent)return next(err);res.status(500).json({error:"Something went wrong. Please try again."});});
(async()=>{
  const fb=await initFirebaseStore();
  try{const result=await hydrateDatabase(db,DB_FILE);console.log('[Khal Live] data source:',result.source,fb.mode);}catch(err){console.error('[Firebase] startup sync failed:',err.message);}
  await syncDatabase(db);
  server.listen(process.env.PORT||3000,()=>console.log("Khal Live running on port "+(process.env.PORT||3000)));
})();

