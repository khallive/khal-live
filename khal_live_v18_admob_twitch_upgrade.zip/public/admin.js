const token = () => localStorage.getItem('khalToken') || '';
async function api(url, opts = {}) {
  opts.headers = { ...(opts.headers || {}), Authorization: 'Bearer ' + token(), 'Content-Type': 'application/json' };
  const r = await fetch(url, opts);
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Request failed');
  return d;
}
const $ = id => document.getElementById(id);
async function load() {
  try {
    const s = await api('/api/admin/stats');
    $('stats').innerHTML = [['Users',s.users],['Live rooms',s.liveRooms],['Viewers',s.viewers],['Open reports',s.reportsOpen],['Coins',s.totalCoins],['Creator coins',s.creatorCoins]]
      .map(x => '<div class="balance-card"><small>'+x[0]+'</small><strong>'+x[1]+'</strong></div>').join('');
    const r = await api('/api/admin/reports');
    $('reports').innerHTML = r.reports.length ? r.reports.map(x =>
      '<article class="admin-item"><b>'+x.reason+'</b><p>'+(x.details || 'No details')+'</p><small>@'+x.reporter+' · '+new Date(x.createdAt).toLocaleString()+' · '+x.status+'</small><div><button data-report="'+x.id+'" data-status="reviewing">Review</button> <button data-report="'+x.id+'" data-status="resolved">Resolve</button> <button data-report="'+x.id+'" data-status="dismissed">Dismiss</button></div></article>'
    ).join('') : '<p class="hint">No reports.</p>';
    const rooms = await (await fetch('/api/rooms')).json();
    $('rooms').innerHTML = rooms.rooms?.length ? rooms.rooms.map(x =>
      '<article class="admin-item"><b>'+x.title+'</b><p>@'+(x.creator?.username || 'unknown')+' · '+x.category+' · '+x.viewers+' viewers</p><small>'+((x.tags||[]).map(t => '#'+t).join(' '))+'</small></article>'
    ).join('') : '<p class="hint">Nobody is live.</p>';
  } catch (e) { $('adminMsg').textContent = e.message; }
}
document.addEventListener('click', async e => {
  const b = e.target.closest('[data-report]');
  if (!b) return;
  try { await api('/api/admin/reports/' + b.dataset.report, {method:'PATCH', body:JSON.stringify({status:b.dataset.status})}); load(); }
  catch (err) { $('adminMsg').textContent = err.message; }
});
load(); setInterval(load, 10000);
