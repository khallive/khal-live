const $=id=>document.getElementById(id);
const room=$("room"), title=$("title"), category=$("category"), preview=$("preview"), start=$("start"), stop=$("stop"), status=$("status"), offline=$("offline"), viewerCount=$("viewerCount");
let ws,stream; const peers=new Map();
function connect(){
 ws=new WebSocket(location.origin.replace(/^http/,"ws"));
 ws.onopen=()=>ws.send(JSON.stringify({type:"join",role:"broadcaster",room:room.value,token:localStorage.getItem("khalToken")||"",title:title.value,category:category.value,tags:(($("tags")?.value||"").split(",").map(x=>x.trim()).filter(Boolean).slice(0,5)),followersOnly:$("followersOnly")?.checked,slowMode:Number($("slowMode")?.value||0)}));
 ws.onmessage=async e=>{
  const m=JSON.parse(e.data);
  if(m.type==="viewer-joined") await offerViewer(m.viewerId);
  if(m.type==="answer") {const pc=peers.get(m.from);if(pc)await pc.setRemoteDescription(m.data)}
  if(m.type==="ice") {const pc=peers.get(m.from);if(pc&&m.data)try{await pc.addIceCandidate(m.data)}catch{}}
  if(m.type==="viewer-left"){const pc=peers.get(m.viewerId);if(pc)pc.close();peers.delete(m.viewerId);updateViewerCount()}
  if(m.type==="error"){status.textContent="Offline";alert(m.error||"Live room error.");endLive()}
 };
}
async function offerViewer(viewerId){
 if(!stream||!ws||ws.readyState!==WebSocket.OPEN)return;
 const pc=new RTCPeerConnection({iceServers:[{urls:"stun:stun.l.google.com:19302"}]});
 peers.set(viewerId,pc); stream.getTracks().forEach(t=>pc.addTrack(t,stream));
 pc.onicecandidate=e=>{if(e.candidate)ws.send(JSON.stringify({type:"ice",to:viewerId,data:e.candidate}))};
 const offer=await pc.createOffer();await pc.setLocalDescription(offer);
 ws.send(JSON.stringify({type:"offer",to:viewerId,data:offer})); updateViewerCount();
}
function updateViewerCount(){if(viewerCount)viewerCount.textContent=String(peers.size)}
async function goLive(){
 if(!localStorage.getItem("khalToken")){alert("Please log in to Khal Live first. Open Profile → Account, then return to Go Live.");return}
 stream=await navigator.mediaDevices.getUserMedia({video:true,audio:true}); preview.srcObject=stream; offline.style.display="none"; connect();
 start.disabled=true;stop.disabled=false;status.textContent="🔴 LIVE";status.className="live";
}
function endLive(){for(const pc of peers.values())pc.close();peers.clear();updateViewerCount();if(stream)stream.getTracks().forEach(t=>t.stop());if(ws)ws.close();preview.srcObject=null;offline.style.display="grid";start.disabled=false;stop.disabled=true;status.textContent="Offline";status.className=""}
start.onclick=()=>goLive().catch(err=>alert("Camera/microphone permission is required: "+err.message));stop.onclick=endLive;

$("scheduleBtn")?.addEventListener("click",async()=>{const token=localStorage.getItem("khalToken");if(!token)return $("scheduleMsg").textContent="Log in first.";try{const r=await fetch("/api/schedules",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+token},body:JSON.stringify({title:title.value,category:category.value,startAt:$("scheduleDate").value})});const d=await r.json();if(!r.ok)throw new Error(d.error||"Could not schedule");$("scheduleMsg").textContent="Scheduled successfully."}catch(e){$("scheduleMsg").textContent=e.message}});
