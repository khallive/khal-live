const $=id=>document.getElementById(id);let mode="login";
function token(){return localStorage.getItem("khalToken")||""}
function setMode(next){mode=next;$('loginTab').classList.toggle('active',mode==='login');$('registerTab').classList.toggle('active',mode==='register');$('displayWrap').classList.toggle('hidden',mode!=='register');$('password').setAttribute('autocomplete',mode==='login'?'current-password':'new-password');$('authMsg').textContent='';}
$('loginTab').onclick=()=>setMode('login');$('registerTab').onclick=()=>setMode('register');
async function api(url,options={}){const headers={'Content-Type':'application/json',...(options.headers||{})};if(token())headers.Authorization='Bearer '+token();const r=await fetch(url,{...options,headers});const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.error||'Something went wrong.');return data;}
async function loadMe(){if(!token()){showAuth();return}try{const {user}=await api('/api/me');showProfile(user)}catch{localStorage.removeItem('khalToken');showAuth()}}
function showAuth(){$('authArea').classList.remove('hidden');$('profileArea').classList.add('hidden')}
function showProfile(u){$('authArea').classList.add('hidden');$('profileArea').classList.remove('hidden');$('avatar').textContent=(u.displayName||u.username).charAt(0).toUpperCase();$('profileName').textContent=u.displayName;$('profileHandle').textContent='@'+u.username;$('profileBio').textContent=u.bio||'No bio yet.';$('followersCount').textContent=u.followers.length;$('followingCount').textContent=u.following.length;$('joinedDate').textContent=new Date(u.createdAt).toLocaleDateString(undefined,{month:'short',year:'numeric'});$('editDisplayName').value=u.displayName;$('editBio').value=u.bio||''}
$('authForm').onsubmit=async e=>{e.preventDefault();$('authMsg').textContent='Working…';try{const body={username:$('username').value,password:$('password').value};if(mode==='register')body.displayName=$('displayName').value;const data=await api(mode==='register'?'/api/register':'/api/login',{method:'POST',body:JSON.stringify(body)});localStorage.setItem('khalToken',data.token);showProfile(data.user)}catch(err){$('authMsg').textContent=err.message}};
$('profileForm').onsubmit=async e=>{e.preventDefault();try{const {user}=await api('/api/profile',{method:'PATCH',body:JSON.stringify({displayName:$('editDisplayName').value,bio:$('editBio').value})});$('profileMsg').textContent='Profile saved.';showProfile(user)}catch(err){$('profileMsg').textContent=err.message}};
$('logoutBtn').onclick=async()=>{try{await api('/api/logout',{method:'POST'})}catch{}localStorage.removeItem('khalToken');showAuth()};
loadMe();


async function loadWallet(){if(!token())return;try{const d=await api('/api/wallet');$('walletCoins').textContent=d.coins;$('creatorCoins').textContent=d.creatorCoins;const box=$('transactions');if(!d.transactions.length){box.innerHTML='<p class="hint">No transactions yet.</p>';return}box.innerHTML=d.transactions.slice(0,12).map(t=>{const sign=t.coins>0?'+':'';const label=t.type.replaceAll('_',' ');return `<div class="transaction"><span><b>${label}</b><small>${new Date(t.createdAt).toLocaleString()}</small></span><strong>${sign}${t.coins} 🪙</strong></div>`}).join('')}catch{}}
$('demoTopup').onclick=async()=>{try{const d=await api('/api/wallet/demo-topup',{method:'POST',body:JSON.stringify({coins:1000})});$('walletMsg').textContent=d.notice;loadWallet()}catch(e){$('walletMsg').textContent=e.message}};
$('payoutBtn').onclick=async()=>{try{const d=await api('/api/payout-request',{method:'POST'});$('walletMsg').textContent=d.message;loadWallet()}catch(e){$('walletMsg').textContent=e.message}};
const oldShowProfile=showProfile; showProfile=function(u){oldShowProfile(u);loadWallet()};
const hashQuery=location.hash.includes("?")?location.hash.split("?")[1]:"";const paymentState=new URLSearchParams(location.search).get("payment")||new URLSearchParams(hashQuery).get("payment");
if(paymentState){setTimeout(()=>{const msg=document.getElementById("walletMsg");if(msg)msg.textContent=paymentState==="success"?"Payment completed. Your coins will appear after the payment webhook is verified.":"Payment cancelled — no coins were added."},300)}

async function loadPaymentOptions(){
  if(!token())return;
  const box=document.getElementById("coinPackages");
  try{
    const cfg=await api("/api/payments/config");
    box.innerHTML=cfg.packages.map(x=>`<button class="coin-package" data-package="${x.id}">${x.label}<small>R${x.amountZar}</small></button>`).join("");
    if(!cfg.enabled){box.insertAdjacentHTML("beforeend",`<p class="hint">Real card payments are not connected yet. The buttons will activate after the server is configured with a payment provider.</p>`);return;}
    box.querySelectorAll(".coin-package").forEach(btn=>btn.onclick=async()=>{
      btn.disabled=true;
      try{const d=await api("/api/payments/create-checkout",{method:"POST",body:JSON.stringify({packageId:btn.dataset.package})});location.href=d.url;}
      catch(e){document.getElementById("walletMsg").textContent=e.message;btn.disabled=false;}
    });
  }catch(e){box.textContent=e.message;}
}
const oldLoadWallet=loadWallet; loadWallet=async function(){await oldLoadWallet();loadPaymentOptions()};
