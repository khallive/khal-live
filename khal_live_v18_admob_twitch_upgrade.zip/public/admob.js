/* Khal Live AdMob integration.
 * Native Android/iOS builds use @capacitor-community/admob.
 * The website remains AdMob-free when opened in a normal browser.
 */
(function(){
  const CONFIG={
    appId:'ca-app-pub-9211419038317507~7775185215',
    bannerId:'ca-app-pub-9211419038317507/7208209004',
    rewardedId:'ca-app-pub-9211419038317507/2816256594',
    appOpenId:'ca-app-pub-9211419038317507/4523858429'
  };
  let admob=null, initialized=false, bannerVisible=false, appOpenLoading=false, lastAppOpen=0, appOpenSuppressed=false;
  function native(){return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());}
  function getPlugin(){
    if(!native()) return null;
    if(admob) return admob;
    try{
      if(window.Capacitor && typeof window.Capacitor.registerPlugin==='function'){
        admob=window.Capacitor.registerPlugin('AdMob');
      }
    }catch(e){console.warn('[Khal AdMob] plugin unavailable',e)}
    return admob;
  }
  async function init(){
    const p=getPlugin(); if(!p) return false;
    try{
      if(p.requestConsentInfo && p.showConsentForm){
        let c=await p.requestConsentInfo();
        if(c && c.isConsentFormAvailable && c.status==='REQUIRED') c=await p.showConsentForm();
        if(c && c.canRequestAds===false) return false;
      }
      if(p.initialize) await p.initialize();
      initialized=true; return true;
    }catch(e){console.warn('[Khal AdMob] init failed',e);return false}
  }
  async function showBanner(){
    if(!(await init())) return false;
    const p=getPlugin();
    try{
      await p.showBanner({adId:CONFIG.bannerId,adSize:'ADAPTIVE_BANNER',position:'BOTTOM_CENTER',margin:0});
      bannerVisible=true; return true;
    }catch(e){console.warn('[Khal AdMob] banner failed',e);return false}
  }
  async function hideBanner(){
    const p=getPlugin(); if(!p) return;
    try{await p.hideBanner();bannerVisible=false}catch(e){console.warn('[Khal AdMob] hide failed',e)}
  }
  async function removeBanner(){
    const p=getPlugin(); if(!p) return;
    try{await p.removeBanner();bannerVisible=false}catch(e){console.warn('[Khal AdMob] remove failed',e)}
  }
  async function showRewarded(){
    if(!(await init())) throw new Error('AdMob consent or initialization is not ready.');
    const p=getPlugin();
    if(!p || !p.prepareRewardVideoAd || !p.showRewardVideoAd) throw new Error('Rewarded ads are not available in this build yet.');
    await p.prepareRewardVideoAd({adId:CONFIG.rewardedId});
    return await p.showRewardVideoAd({adId:CONFIG.rewardedId});
  }

  async function loadAppOpen(){
    if(!(await init())||appOpenLoading)return false;
    const p=getPlugin(); if(!p||!p.loadAppOpen)return false;
    try{appOpenLoading=true;await p.loadAppOpen({adId:CONFIG.appOpenId});appOpenLoading=false;return true}catch(e){appOpenLoading=false;console.warn('[Khal AdMob] app open load failed',e);return false}
  }
  async function showAppOpen(){
    if(appOpenSuppressed||document.body.classList.contains('modal-open')||Date.now()-lastAppOpen<120000)return false;
    if(!(await init()))return false;
    const p=getPlugin();if(!p||!p.isAppOpenLoaded||!p.showAppOpen)return false;
    try{const ready=await p.isAppOpenLoaded({adId:CONFIG.appOpenId});if(!ready?.value){await loadAppOpen();const again=await p.isAppOpenLoaded({adId:CONFIG.appOpenId});if(!again?.value)return false}await p.showAppOpen({adId:CONFIG.appOpenId});lastAppOpen=Date.now();setTimeout(loadAppOpen,1000);return true}catch(e){console.warn('[Khal AdMob] app open show failed',e);return false}
  }
  window.khalAdMob={CONFIG,init,showBanner,hideBanner,removeBanner,showRewarded,loadAppOpen,showAppOpen,isNative:native};
  document.addEventListener('DOMContentLoaded',()=>{
    if(!native()) return;
    // Banner is intentionally limited to discovery/home; live video is not interrupted.
    setTimeout(async()=>{ if(location.pathname==='/' || location.pathname.endsWith('/index.html')) { showBanner(); await loadAppOpen(); setTimeout(showAppOpen,1200); } },900);
    document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible' && (location.pathname==='/' || location.pathname.endsWith('/index.html'))) showAppOpen()});
  });
})();
