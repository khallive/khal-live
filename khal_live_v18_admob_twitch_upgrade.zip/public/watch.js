const params=new URLSearchParams(location.search), room=params.get("room")||"main";
const player=document.getElementById("player"), waiting=document.getElementById("waiting"), state=document.getElementById("state"), messages=document.getElementById("messages"), form=document.getElementById("chat"), input=document.getElementById("chatText"); let creatorUsername="";
let ws,pc,broadcasterId,reconnectTimer,reconnectAttempts=0;
function addMsg(name,text){const d=document.createElement("div");const b=document.createElement("b");b.textContent=name;d.appendChild(b);d.appendChild(document.createTextNode(": "+text));messages.appendChild(d);messages.scrollTop=messages.scrollHeight}
function connect(){
 ws=new WebSocket(location.origin.replace(/^http/,"ws"));
 ws.onopen=()=>{
    reconnectAttempts=0;
    state.textContent="Connected. Waiting for the stream…";
    ws.send(JSON.stringify({type:"join",role:"viewer",room,token:localStorage.getItem("khalToken")||""}));
  };
 ws.onmessage=async e=>{const m=JSON.parse(e.data);
  if(m.type==="broadcaster-present"){broadcasterId=m.broadcasterId;creatorUsername=m.creator?.username||"";state.textContent="Broadcaster detected. Connecting…";document.getElementById("streamTitle").textContent=m.title||"Khal Live";document.getElementById("streamCategory").textContent=m.category||"Just Chatting";document.getElementById("creatorName").textContent=m.creator?.displayName?"@"+m.creator.displayName:"Khal Creator";const follow=document.getElementById("followBtn");if(creatorUsername){follow.style.display="inline-flex";follow.onclick=async()=>{const t=localStorage.getItem("khalToken");if(!t){document.getElementById("giftMsg").textContent="Log in first to follow this creator.";return}const r=await fetch("/api/follow",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+t},body:JSON.stringify({username:creatorUsername})});const d=await r.json();document.getElementById("giftMsg").textContent=r.ok?(d.following?"Following @"+creatorUsername:"Unfollowed @"+creatorUsername):(d.error||"Could not update follow.");if(r.ok)follow.textContent=d.following?"✓ Following":"♡ Follow"}}}
  if(m.type==="offer"){
    broadcasterId=m.from; pc=new RTCPeerConnection({iceServers:[{urls:"stun:stun.l.google.com:19302"}]});
    pc.ontrack=e=>{player.srcObject=e.streams[0];waiting.style.display="none";state.textContent="🔴 LIVE"};
    pc.onicecandidate=e=>{if(e.candidate)ws.send(JSON.stringify({type:"ice",to:"broadcaster",data:e.candidate}))};
    await pc.setRemoteDescription(m.data);const ans=await pc.createAnswer();await pc.setLocalDescription(ans);ws.send(JSON.stringify({type:"answer",data:ans}));
  }
  if(m.type==="ice"&&pc&&m.data)try{await pc.addIceCandidate(m.data)}catch{}
  if(m.type==="broadcaster-left"){if(pc)pc.close();waiting.style.display="grid";state.textContent="Broadcaster is offline"}
  if(m.type==="chat")addMsg(m.name,m.text);
   if(m.type==="chat-error")addMsg("Khal Live",m.error||"Message could not be sent.");
   if(m.type==="chat-sent" && m.clientMessageId){/* delivery acknowledgement */}
  if(m.type==="gift"){addMsg("🎁",m.gift.from+" sent "+m.gift.emoji+" "+m.gift.name);const b=document.createElement("div");b.className="gift-pop";b.textContent=m.gift.emoji;document.body.appendChild(b);setTimeout(()=>b.remove(),1800)}
 };
 ws.onclose=()=>{
    state.textContent="Connection lost. Reconnecting…";
    reconnectAttempts=Math.min(reconnectAttempts+1,6);
    reconnectTimer=setTimeout(connect,Math.min(1000*Math.pow(2,reconnectAttempts-1),15000));
  };
}
form.onsubmit=e=>{
  e.preventDefault();
  const text=input.value.trim();
  if(!text)return;
  if(!ws||ws.readyState!==WebSocket.OPEN){addMsg("Khal Live","Chat is reconnecting. Please try again.");return;}
  const clientMessageId=(crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random());
  ws.send(JSON.stringify({type:"chat",text,clientMessageId}));
  input.value="";
};
connect();
async function refreshCoins(){const t=localStorage.getItem("khalToken");if(!t)return;try{const r=await fetch("/api/wallet",{headers:{Authorization:"Bearer "+t}});if(r.ok){const d=await r.json();document.getElementById("coinBalance").textContent="Coins: "+d.coins}}catch{}}
document.querySelectorAll(".gift").forEach(btn=>btn.onclick=async()=>{const t=localStorage.getItem("khalToken"),msg=document.getElementById("giftMsg");if(!t){msg.textContent="Log in first to send gifts.";return}btn.disabled=true;try{const r=await fetch("/api/gifts/send",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+t},body:JSON.stringify({gift:btn.dataset.gift,room})});const d=await r.json();if(!r.ok)throw new Error(d.error||"Gift failed");msg.textContent=d.gift.emoji+" Gift sent!";document.getElementById("coinBalance").textContent="Coins: "+d.coins}catch(e){msg.textContent=e.message}finally{btn.disabled=false}});refreshCoins();

document.getElementById("clipBtn")?.addEventListener("click",async()=>{const t=localStorage.getItem("khalToken"),msg=document.getElementById("giftMsg");if(!t)return msg.textContent="Log in first to create a clip.";try{const r=await fetch("/api/clips",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+t},body:JSON.stringify({room,title:document.getElementById("streamTitle")?.textContent})});const d=await r.json();msg.textContent=r.ok?"✂ 15-second clip created!":"Clip: "+(d.error||"failed")}catch(e){msg.textContent=e.message}});
document.getElementById("reportBtn")?.addEventListener("click",async()=>{const t=localStorage.getItem("khalToken"),msg=document.getElementById("giftMsg");if(!t)return msg.textContent="Log in first to report a stream.";const reason=prompt("Why are you reporting this stream? (spam, harassment, unsafe, copyright, other)","other");if(!reason)return;try{const r=await fetch("/api/report",{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+t},body:JSON.stringify({room,reason})});const d=await r.json();msg.textContent=r.ok?"Report submitted. Thank you.":(d.error||"Report failed")}catch(e){msg.textContent=e.message}});
