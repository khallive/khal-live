(()=>{
const token=()=>localStorage.getItem('khalToken')||'';
const api=async(url,options={})=>{const headers={'Content-Type':'application/json',...(options.headers||{})};if(token())headers.Authorization='Bearer '+token();const r=await fetch(url,{...options,headers});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Something went wrong.');return d};
const $=id=>document.getElementById(id); const fields=['darkMode','reduceMotion','liveNotifications','accountNotifications','storyNotifications','autoplay','muted','pip','chatVisible','chatSounds','personalized'];
function apply(p){fields.forEach(k=>{const el=$('pref'+k.charAt(0).toUpperCase()+k.slice(1));if(el)el.checked=!!p[k]});document.body.classList.toggle('reduce-motion',!!p.reduceMotion);document.body.classList.toggle('light-mode',!p.darkMode);}
async function load(){if(!token()){ $('settingsMsg').textContent='Log in to manage settings.'; return }try{const d=await api('/api/settings');$('settingsUsername').textContent='@'+d.user.username;$('settingsDisplayName').textContent=d.user.displayName;apply(d.preferences)}catch(e){$('settingsMsg').textContent=e.message}}
async function save(){try{const preferences={};fields.forEach(k=>{const el=$('pref'+k.charAt(0).toUpperCase()+k.slice(1));preferences[k]=!!el?.checked});const d=await api('/api/settings',{method:'PATCH',body:JSON.stringify(preferences)});apply(d.preferences);$('settingsMsg').textContent='Settings saved.';setTimeout(()=>{$('settingsMsg').textContent=''},2200)}catch(e){$('settingsMsg').textContent=e.message}}
document.querySelectorAll('[data-setting-tab]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-setting-tab]').forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('[data-setting-panel]').forEach(x=>x.classList.toggle('active',x.dataset.settingPanel===b.dataset.settingTab))});
$('saveSettings').onclick=save;
$('settingsLogout').onclick=async()=>{try{await api('/api/logout',{method:'POST'})}catch{}localStorage.removeItem('khalToken');location.reload()};
$('privacyBtn').onclick=()=>{if(window.parent&&window.parent.openModal)window.parent.openModal('privacy')};
$('blockedUsersBtn').onclick=async()=>{try{const d=await api('/api/blocks');const list=d.blocks.length?d.blocks.map(x=>`• @${x.username}`).join('<br>'):'No blocked users.';$('settingsMsg').innerHTML=list}catch(e){$('settingsMsg').textContent=e.message}};
load();
})();
