# Khal Live v9 — Unified professional app

One responsive Khal Live application shell. Home, live discovery, following, categories, wallet, profile, account, creator studio, watch/chat, privacy and terms are accessed within the same branded interface. Account UI is mounted inside the app panel and its account script initializes there; watch and studio run in an in-app embedded view so camera, microphone and WebRTC behavior stays isolated while visually remaining inside Khal Live.

## Run on Windows
1. Install Node.js LTS from https://nodejs.org/.
2. Extract this ZIP.
3. Double-click `START_KHAL_LIVE.bat`.
4. Open http://localhost:3000.

## Phone preview
Run the server on your computer, connect phone and computer to the same Wi-Fi, find the computer IPv4 address with `ipconfig`, then visit `http://YOUR-IP:3000` on the phone. Mobile camera/microphone access generally requires HTTPS or localhost; ordinary HTTP over a LAN may be blocked by mobile browsers.

## Notes
This is a development preview. Coin top-ups are demo-only; real payments and payouts remain disabled pending provider setup. Browser-to-browser WebRTC is suitable only for small tests, not production scale. Production launch still requires a managed media server/CDN, hosted database, HTTPS, security review, moderation operations, payment verification, payout compliance, and app-store release work.


## Pre-launch hardening in this build
- Live-room viewer counting uses the room peer set correctly.
- Only authenticated users can become broadcasters.
- A live room cannot have two broadcasters at once.
- Auth, payment, gift, and payout endpoints have basic rate limiting.
- Payment success/cancel returns to the Khal Live app shell.
- Basic security response headers are enabled.
- A `/api/health` endpoint is available for deployment checks.

This remains a development build until a production database, media server/CDN, payment provider, payout provider, monitoring, backups, moderation tooling, and full security review are connected.


## Current pre-launch state
- Unified Khal Live app shell with Home, Live, Following, Categories, Wallet, Profile, Creator Studio and Watch.
- Live discovery now shows only authenticated live rooms; no fake offline channels are presented as live.
- Creators can choose a category when starting a stream.
- Viewers can follow the live creator from the watch screen and see followed live creators in Following/Notifications.
- Real payments remain disabled until the payment provider is configured.
- Creator payouts remain disabled until a payout provider is configured; creator coins are not removed while payouts are unavailable.
- Demo coin top-ups are for local testing only and do not charge money.

For public production launch, the remaining infrastructure work is a production media/CDN service, persistent database, real payout provider, HTTPS deployment, moderation/reporting, monitoring, backups, and legal review of Terms/Privacy.


Khal Live v12 — repaired package
This archive is rebuilt from the verified Khal Live v11 build. The previous v12 archive was invalid/empty.
