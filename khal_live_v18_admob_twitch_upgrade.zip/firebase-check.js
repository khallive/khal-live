const { initFirebaseStore, firebaseDiagnostic } = require('./firebase-store');
(async()=>{
  const result = await initFirebaseStore();
  const diagnostic = await firebaseDiagnostic();
  console.log(JSON.stringify({ initialization: result, diagnostic }, null, 2));
  process.exit(diagnostic.connected ? 0 : 1);
})().catch(err=>{ console.error(err); process.exit(1); });
